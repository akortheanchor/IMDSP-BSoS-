'use client';

import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from 'recharts';

const vitalsData = [
  { time: '08:00', HR: 72, SpO2: 98 },
  { time: '09:00', HR: 75, SpO2: 97 },
  { time: '10:00', HR: 110, SpO2: 94 },
  { time: '11:00', HR: 80, SpO2: 96 },
  { time: '12:00', HR: 70, SpO2: 98 }
];

export default function Page() {
  return (
    <main className="grid grid-cols-1 md:grid-cols-2 gap-6 p-6">
      <Card>
        <CardContent className="space-y-4">
          <h2 className="text-xl font-semibold">Patient Context Parameters</h2>
          <div className="space-y-2">
            <div className="flex justify-between">
              <Label>Activity Level</Label>
              <Progress value={60} className="w-2/3" />
            </div>
            <div className="flex justify-between">
              <Label>Baseline Vitals Deviation</Label>
              <Progress value={30} className="w-2/3" />
            </div>
            <div className="flex justify-between">
              <Label>Time of Day (Context Weight)</Label>
              <Progress value={80} className="w-2/3" />
            </div>
            <div className="flex justify-between">
              <Label>Environmental Impact</Label>
              <Progress value={45} className="w-2/3" />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent>
          <h2 className="text-xl font-semibold mb-4">Real-Time Vitals Monitoring</h2>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={vitalsData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="time" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="HR" stroke="#8884d8" name="Heart Rate" />
              <Line type="monotone" dataKey="SpO2" stroke="#82ca9d" name="SpO₂" />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card className="md:col-span-2">
        <CardContent className="space-y-4">
          <h2 className="text-xl font-semibold">Sensor Control</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex items-center space-x-2">
              <Switch defaultChecked id="core" />
              <Label htmlFor="core">Core Sensors</Label>
            </div>
            <div className="flex items-center space-x-2">
              <Switch id="activity" />
              <Label htmlFor="activity">Activity Sensors</Label>
            </div>
            <div className="flex items-center space-x-2">
              <Switch id="full" />
              <Label htmlFor="full">Full Sensor Set</Label>
            </div>
          </div>
        </CardContent>
      </Card>
    </main>
  );
}
